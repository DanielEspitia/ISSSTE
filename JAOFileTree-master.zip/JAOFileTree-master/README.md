# JAOFileTree

Just another jQuery file tree plugin

## Documentation

[https://github.com/Jiwoks/JAOFileTree/wiki/Documentation](https://github.com/Jiwoks/JAOFileTree/wiki/Documentation)

## Demo

[http://sandbox.crac-design.com/jaofiletree/](http://sandbox.crac-design.com/jaofiletree/)

## Licence
[http://www.gnu.org/licenses/gpl.html](http://www.gnu.org/licenses/gpl.html)

[http://opensource.org/licenses/MIT](http://opensource.org/licenses/MIT)
